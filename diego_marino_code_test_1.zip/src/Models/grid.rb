class Grid
  attr_accessor :size, :matrix

  def initialize(size)
    @size = size
    @matrix = generate_matrix
  end

  def print_matrix
    @matrix.each do |m|
      print "#{m}\n"
    end
  end

  private

  def generate_matrix
    matrix = []
    for i in 0..(@size-1)
      line = []
      for j in 0..(@size-1)
        line.push(rand(65..90).chr)
      end
      matrix.push(line)
    end
    matrix
  end
end
