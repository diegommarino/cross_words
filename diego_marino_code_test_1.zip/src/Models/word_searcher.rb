class WordSearcher
  attr_accessor :letters_grid, :words_dict, :finded_words

  def initialize(letters_grid, words_dict)
    @letters_grid = letters_grid
    @words_dict = words_dict.compact
    @finded_words = []
    find_words
  end

  def find_words
    @finded_words += left_to_right_search
    @finded_words += right_to_left_search
    @finded_words += top_to_bottom_search
    @finded_words += bottom_to_top_search
    @finded_words.uniq!
  end

  def left_to_right_search
    finded_words = []
    for i in 0..(@letters_grid.size - 1)
      line_string = @letters_grid[i].join()
      @words_dict.each do |word|
        finded_words.push(word) if line_string.include?(word)
      end
    end
    finded_words
  end

  def right_to_left_search
    finded_words = []
    for i in 0..(@letters_grid.size - 1)
      line_string = @letters_grid[i].reverse.join()
      @words_dict.each do |word|
        finded_words.push(word) if line_string.include?(word)
      end
    end
    finded_words
  end

  def top_to_bottom_search
    finded_words = []
    for i in 0..(@letters_grid.size - 1)
      column_string = *(0..(@letters_grid.size - 1)).map { |j| @letters_grid[j][i]}.join()
      @words_dict.each do |word|
        finded_words.push(word) if column_string.include?(word)
      end
    end
    finded_words
  end

  def bottom_to_top_search
    finded_words = []
    for i in 0..(@letters_grid.size - 1)
      column_string = *(0..(@letters_grid.size - 1)).map { |j| @letters_grid[j][i]}.reverse.join()
      @words_dict.each do |word|
        finded_words.push(word) if column_string.include?(word)
      end
    end
    finded_words
  end
end
