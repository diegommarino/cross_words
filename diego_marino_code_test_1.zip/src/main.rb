$LOAD_PATH.unshift(File.dirname(__FILE__))
require 'Models/grid'
require 'Models/word_searcher'

words_dict = []
file = 'dict.txt'

File.readlines(file).each do |line|
  words_dict.push(line.split(' ').first)
end

grid = Grid.new(4)
searcher = WordSearcher.new(grid.matrix, words_dict)
print searcher.finded_words
